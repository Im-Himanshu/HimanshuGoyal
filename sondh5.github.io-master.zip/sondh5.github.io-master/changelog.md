# Mediumish Jekyll Theme - Change Log

## 2019-02-14

### Fixed
- Feed site title not showing

### Added
- 404 page


## 2019-02-10

### Fixed
- CSS Jumbotron categories

## 2019-02-09

### Fixed
- Category links are now compatible with Github pages. Archive still available for non Github pages.

### Added
- Search
- SEO

## 2018-11-08

### Fixed
- fixed reponsive footer jumbotron for tags

## 2018-11-07

### Added
- external image support

## 2018-09-12

### Added
- disable comments in a specific post with `comments: false` in YAML front matter

### Updated
- Bootstrap v4.1.3
- jQuery v3.3.1
---
layout: post
title:  "Nguyên team đi vào hết"
author: sondh5
status: "private"
---

1. Module và Class giống và khác?
2. Array và Hash giống và khác?
3. Symbol và String giống và khác?
4. Method setter và getter trong ruby
5. 4 tính chất OOP
6. Private, protected và public
7. Class method và object method (cả ruby và rails)
8. Luồng xử lí của 1 request từ browser đi qua những tầng nào
9. Instance variable là gì?
10. 7 verb method HTTP
11. Thin controller & fat model
12. Cách tổ chức source code của 1 project Rails
13. Helper, decorator, service, lib
14. Assets precompile
15. Worker, sidekiq, cronjob
16. Concern
17. Associations
18. ORM
19. N+1 query và cách xử lí
20. Cache
21. AWS basic
22. Deploy
